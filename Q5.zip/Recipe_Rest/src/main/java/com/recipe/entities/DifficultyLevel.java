package com.recipe.entities;

public enum DifficultyLevel {
	EASY,MEDIUM,HARD;

}
