package com.recipe.entities;

public enum CuisineType {
	INDIAN,CHINESE,ITALIAN,MEXICAN;
}
