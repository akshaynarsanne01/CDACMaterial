package com.recipe.exception;

public class RecipeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RecipeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
