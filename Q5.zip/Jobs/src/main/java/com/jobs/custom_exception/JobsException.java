package com.jobs.custom_exception;

public class JobsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JobsException(String message) {
		super(message);
	}

}
