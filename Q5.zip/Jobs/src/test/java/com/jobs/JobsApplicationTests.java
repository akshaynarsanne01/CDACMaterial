package com.jobs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobsApplicationTests {

	@Test
	void contextLoads() {
	}

}
