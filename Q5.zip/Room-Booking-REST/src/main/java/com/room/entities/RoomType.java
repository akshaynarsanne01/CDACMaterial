package com.room.entities;

public enum RoomType {
	SINGLE, DOUBLE, SUITE;
}
