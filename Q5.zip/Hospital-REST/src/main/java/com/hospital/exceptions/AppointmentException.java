package com.hospital.exceptions;

public class AppointmentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppointmentException(String message) {
		super(message);
	}
	

}
