package com.course.entities;

public enum Grade {
	A,B,C,D,E;
}
