package com.course.entities;

public enum Category {
	JAVA_BEGINER, JAVA_ADVANCED;
}
