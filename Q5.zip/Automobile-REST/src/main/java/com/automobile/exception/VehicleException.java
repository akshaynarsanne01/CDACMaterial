package com.automobile.exception;

public class VehicleException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
