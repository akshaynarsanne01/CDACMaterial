package com.automobile.entities;

public enum Company {
	HERO, HONDA, BAJAJ, ROYAL_ENFIELD, JAVA, ROLLS_ROICE;
}
