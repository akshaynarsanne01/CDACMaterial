package com.automobile.entities;

public enum VehicleType {
	BIKE, SEDAN, CRUISER;
}
