#include<iostream>
using namespace std;
class sample
{
   private:
	   const int k;
	   
	
   public:
	   sample():k(0){

	   }
	   sample(int n):k(n)
	   {
		   n=12;
	  
	   
	   }

         void print()
	 {
	     cout<<"value of k is "<<k;
	 }

};
int main()
{
	int n =10;
	sample s(n);
	s.print();
	return 0;
}



