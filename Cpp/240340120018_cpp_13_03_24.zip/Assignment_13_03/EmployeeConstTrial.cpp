#include<iostream>
#include<string>
using namespace std;

class Employee{
	private:
		int employeeId;
		string name;
		double salary;
	public:
		Employee(){
			employeeId = 0;
			name = "";
			salary = 0.0;
		}
		Employee(int emplyeeId,string name,double salary){
			this->employeeId = employeeId;
			this->name = name;
			this->salary = salary;
		}
		void accept();
		void display() const ;
};
void Employee:: accept(){
	cout<<"Enter employee Id : ";
	cin>>this->employeeId;
	cout<<"Enter the name of Employee : ";
	cin>>this->name;
	cout<<"Enter the salary of employee : ";
	cin>>this->salary;
}
void Employee :: display() const {
	cout<<"Employee ID is : "<<this->employeeId<<endl;
	cout<<"Name of employee is : "<<this->name<<endl;
	cout<<"Salary of employee is : "<<this->salary<<endl;
}
int main(){
	
	//Employee s1;
	//s1.accept();
	//s1.display();
	//const Employee s2;
	//s2.accept();
	//Employee s3(10,"vivek",100);
	//s3.display();
	const Employee s4;
	s4.display();
	return 0;
}
//object non constant and member function non constant -> we can read and write both // not error
//object non constant and member function is constant -> we can on only read // not error// we cannot write values
//object constant and member function is non constant -> we can only read (Error)
//object constant & member function constant -> we can read the data members //not error
