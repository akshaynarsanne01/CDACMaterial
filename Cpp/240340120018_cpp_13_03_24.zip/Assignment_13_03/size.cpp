#include<iostream>
using namespace std;
class size1
{
  private:
	//int k;
	//string name;
       //static int no;
        



};
int main()
{
 size1 *s;
 cout<<"size of class is "<<sizeof(s);
 return 0;





}
