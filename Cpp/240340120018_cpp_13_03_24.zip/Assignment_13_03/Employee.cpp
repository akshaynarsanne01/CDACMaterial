#include<iostream>
#include<string>
using namespace std;

class Employee{
	private:
		int employeeId;
		string name;
		double salary;
	 	static int count;
	public:
		Employee(){
			employeeId = 0;
			name = "";
			salary = 0.0;
			count += 1;
		}
		void accept();
		void display();
		static void employeeCount(){
			cout<<"object initialized count are : "<<count<<endl;
		}
};
void Employee:: accept(){
	cout<<"Enter employee Id : ";
	cin>>this->employeeId;
	cout<<"Enter the name of Employee : ";
	cin>>this->name;
	cout<<"Enter the salary of employee : ";
	cin>>this->salary;
}
void Employee :: display(){
	cout<<"Employee ID is : "<<this->employeeId<<endl;
	cout<<"Name of employee is : "<<this->name<<endl;
	cout<<"Salary of employee is : "<<this->salary<<endl;
}
int Employee :: count;
int main(){
	
	Employee s1;
	s1.accept();
	s1.display();
	Employee::employeeCount();
	return 0;
}
