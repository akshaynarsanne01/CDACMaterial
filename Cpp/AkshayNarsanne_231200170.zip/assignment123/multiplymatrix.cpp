#include<iostream>
using namespace std;

#include "multiplymatrix.h"
void acceptMatrix(int **matrix1,int **matrix2,int n,int m){	
	cout<<"Enter the values of first matrix : "<<endl;
	for(int i=0;i<n;i++){
		for (int j=0;j<m;j++){
			cin>>matrix1[i][j];
		}
	}
	cout<<"Enter the values of second matrix : "<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>matrix2[i][j];
		}
	}
}
void multiplyMatrix(int **matrix1,int **matrix2,int **matrix3,int n,int m){
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			matrix3[i][j] = matrix1[i][j] * matrix2[i][j];
		}
	}
}
void printMatrix(int **matrix3,int n,int m){
	cout<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cout<<" "<<matrix3[i][j]<<" ";
		}
		cout<<endl;
	}
}
