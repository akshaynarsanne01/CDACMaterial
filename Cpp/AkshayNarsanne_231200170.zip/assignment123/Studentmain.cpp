#include<bits/stdc++.h>
using namespace std;
class Student{
	private :
		int rollNumber;
		string name;
		int marks;
	public :
		Student(){
			rollNumber = 0;
			name = "";
			marks = 0;
		}
		void acceptInput();
		void displayData();
		int getrollnumber(){
			return rollNumber;
		}
		int getmarks(){
			return marks;
		}
		string getname(){
			return name;
		}
};

void Student :: acceptInput(){
	cout<<"Enter the roll number:";
	cin>>rollNumber;	
	cout<<"Enter the name :";
	cin>>name;
	cout<<"Enter the marks:";
	cin>>marks;
}
void Student :: displayData(){
	cout<<"Roll number is : "<<rollNumber<<endl;
	cout<<"Name is : "<<name<<endl;
	cout<<"marks are : "<<marks<<endl;
}
void sortRoll(Student array[],int n){
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(array[i].getrollnumber() > array[j].getrollnumber()){
				Student temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}
		}
	}
}
void sortMarks(Student array[],int n){
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(array[i].getmarks() > array[j].getmarks()){
				Student temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}
		}
	}
}
void sortName(Student array[],int n){
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(array[i].getname() > array[j].getname()){
				Student temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}
		}
	}
}
int main(){
	int n;
	cout<<"Enter the number of students you want to store :";
	cin>>n;
	Student* array = new Student[n];
	for(int i=0;i<n;i++){
		array[i];
	}
	int choice;
	choice = 1;
	while(choice != 5){
		cout<<"1.Accept data from user\n";
		cout<<"2. Display data of all students\n";
		cout<<"3. Sort by roll number\n";
		cout<<"4. Sort by marks\n";
		cout<<"5. Sort by name\n";
		cout<<"6. Exit\n";
		cout<<"Enter your choice: ";
		cin>>choice;
		switch(choice){
			case 1: 
				for(int i=0;i<n;i++){
					array[i].acceptInput();
				}
				break;
			case 2:
				for(int i=0;i<n;i++){
					array[i].displayData();
				}
				break;
			case 3:
				sortRoll(array,n);
				for(int i=0;i<n;i++){
					array[i].displayData();
				}
				break;
			case 4:
				sortMarks(array,n);
				for(int i=0;i<n;i++){
					array[i].displayData();
				}
				break;
			case 5:
				sortName(array,n);
				for(int i=0;i<n;i++){
					array[i].displayData();
				}
				break;
			case 6:
				exit;
		}
	}
	return 0;
}
