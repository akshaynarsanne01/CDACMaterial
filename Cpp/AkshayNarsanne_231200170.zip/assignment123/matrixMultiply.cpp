#include<iostream>
#include "multiplymatrix.h"
using namespace std;
int main(){

	int n;
	int m;
	cout<<"Enter the row size : ";
	cin>>n;
	cout<<"Enter the column size : ";
	cin>>m;
	int **matrix1 = new int*[n];
	int **matrix2 = new int*[n];
	int **matrix3 = new int*[n];
	for(int i=0;i<n;i++){
		matrix1[i] = new int[m];
	}
	for(int i=0;i<n;i++){
		matrix2[i] = new int[m];
	}
	for(int i=0;i<n;i++){
		matrix3[i] = new int[m];
	}
	acceptMatrix(matrix1,matrix2,n,m);
	multiplyMatrix(matrix1,matrix2,matrix3,n,m);
	cout<<"\nFirst matrix is : ";
	printMatrix(matrix1,n,m);
	cout<<"\nsecond matrix is : ";
	printMatrix(matrix2,n,m);
	cout<<"\nmultiplied matrix is : ";
	printMatrix(matrix3,n,m);
	return 0;
}

