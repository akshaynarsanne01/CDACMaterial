void multiplyMatrix(int **matrix1,int **matrix2,int **matrix3,int n,int m);
void printMatrix(int **matrix3,int n,int m);
void acceptMatrix(int **matrix1,int **matrix2,int n,int m);
