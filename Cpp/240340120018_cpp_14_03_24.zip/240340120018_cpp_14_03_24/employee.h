#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>
#include<string>
using namespace std;

class Employee{
	private:
		int employeeId;
		string name;
		double salary;
	public:
		Employee(){
			employeeId = 0;
			name = "";
			salary = 0.0;
		}
		void accept();
		void display();
		double getSalary();
};
#endif
