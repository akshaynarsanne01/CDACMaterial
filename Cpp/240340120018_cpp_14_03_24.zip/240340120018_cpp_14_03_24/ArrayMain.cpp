#include<iostream>
#include<string>
#include "Arraypractice.h"
using namespace std;
int main(){
	int n;
	cout<<"Enter the how many number of data you want to insert : ";
	cin>>n;
	int m;
	cout<<"Enter the inner array size : ";
	cin>>m;

	ArrayClass* data = new ArrayClass[n];
	for(int i=0;i<n;i++){
		data[i] = ArrayClass(m); // this object statement makes shallow copy and points all the array of objects to the same array
	}
	for(int i=0;i<n;i++){
		data[i].accept(m);
	}
	for(int i=0;i<n;i++){
		data[i].display(m);
	}
	/*
	ArrayClass obj(1);
	obj.accept(1);
	obj.display(1);
	*/
	return 0;
}
