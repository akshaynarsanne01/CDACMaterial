#include<iostream>
using namespace std;

void swapTwo(int &a,int &b){
	int temp = a;
	a = b;
	b=temp;
}
int main(){

	int number1, number2;
	cout<<"Enter two numbers : ";
	cin>>number1>>number2;
	cout<<"\nBefore swap two numbers are :"<<number1<<" "<<number2<<endl;
	swapTwo(number1,number2);
	cout<<"\nAfter swap two numbers are :"<<number1<<" "<<number2<<endl;
	return 0;
}
