#include<iostream>
#include<string>
#include "employee.h"
#include "utils.h"

using namespace std;

int main(){
	
	int n;
	cout<<"Enter the number of data you want to insert : ";
	cin>>n;

	Employee *Array = new Employee[n];
	for(int i=0;i<n;i++){
		Array[i];
	}
	int choice=1;
	while(choice != 4){
		cout<<"1.Accept data from user\n";
		cout<<"2. Display data of all students\n";
		cout<<"3. Sort by salary\n";
		cout<<"4. Exit\n";
		cout<<"Enter your choice: ";
		cin>>choice;
		switch(choice){
			case 1: 
				for(int i=0;i<n;i++){
					Array[i].accept();
				}
				break;
			case 2:
				for(int i=0;i<n;i++){
					Array[i].display();
				}
				break;
			case 3:
				sortSalary(Array,n);
				for(int i=0;i<n;i++){
					Array[i].display();
				}
				break;
			case 4:
				exit;
		}
	}
	
	return 0;
}
