#ifndef ARRAYPRACTICE_H
#define ARRAYPRACTICE_H
#include<iostream>
#include<string>
using namespace std;

class ArrayClass{
	private:
		int *p;
		string name;
		int size;
	public:
		ArrayClass();
		ArrayClass(int size);
		void accept(int m);
		void display(int m);
		void setIndexAt(int index,int value);
		int getIndexAt(int index);
		~ArrayClass();
};
#endif
