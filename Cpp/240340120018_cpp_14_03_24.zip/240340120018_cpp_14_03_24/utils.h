#ifndef UTILS_H
#define UTILS_H

void sortSalary(Employee array[],int n);

#endif
