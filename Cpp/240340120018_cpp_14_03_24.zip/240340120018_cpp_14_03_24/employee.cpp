#include "employee.h"
#include<iostream>
#include<string>
using namespace std;

void Employee:: accept(){
	cout<<"Enter employee Id : ";
	cin>>this->employeeId;
	cout<<"Enter the name of Employee : ";
	cin>>this->name;
	cout<<"Enter the salary of employee : ";
	cin>>this->salary;
}
void Employee :: display(){
	cout<<"Employee ID is : "<<this->employeeId<<endl;
	cout<<"Name of employee is : "<<this->name<<endl;
	cout<<"Salary of employee is : "<<this->salary<<endl;
}
double Employee :: getSalary(){
	return salary;
}
