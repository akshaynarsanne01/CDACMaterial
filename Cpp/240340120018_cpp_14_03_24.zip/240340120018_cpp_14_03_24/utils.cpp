#include<iostream>
#include<string>
#include "employee.h"
#include "utils.h"
using namespace std;

void sortSalary(Employee array[],int n){
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(array[i].getSalary() > array[j].getSalary()){
				Employee temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			}
		}
	}
}
