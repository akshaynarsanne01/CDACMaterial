#include<iostream>
#include<string>
#include "Arraypractice.h"
using namespace std;

ArrayClass :: ArrayClass(){
	p = nullptr;
}
ArrayClass :: ArrayClass(int size){
	p = new int[size];
}
void ArrayClass :: accept(int m){
	cout<<"Enter the name : ";
	cin>>this->name;
	for(int i=0;i<m;i++){
		cout<<"Enter the index of p at "<<i+1<<" : ";
		int value;
		cin>>value;
		setIndexAt(i,value);
	}
}
void ArrayClass :: display(int m){
	cout<<"Name is :"<<this->name<<endl;
	for(int i=0;i<m;i++){
		cout<<"Value at index of p is : "<<getIndexAt(i)<<endl;
	}	
}
void ArrayClass :: setIndexAt(int index,int value){
	p[index]=value;
}
int ArrayClass :: getIndexAt(int index){
	return p[index];
}	
ArrayClass :: ~ArrayClass(){
	delete [] p;
}

